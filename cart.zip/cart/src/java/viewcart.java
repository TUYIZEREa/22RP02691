

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USER
 */
public class viewcart extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
         out.println("<center>");
          out.println("");
        out.println("<h1 style=' background-color: green;\n" +"color: white;'>Your Shopping Cart</h1>");
        
       
        
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().startsWith("")) {
                    out.println("<li>" + cookie.getValue() + " <button><a href='RemoveItemServlet?item=" + cookie.getValue() + "'>Remove</a></button></li>");
                }
            }
        }
      out.println("<br><br>");
        out.println("<button><a href='clearServlet'>Clear Cart</a></button>");
        out.println("<button><a href='index.html'>Continue Shopping</a></button>");
    }

}
